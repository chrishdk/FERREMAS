from .models import Producto
from .serializers import ProductoSerializer

def get_all_productos():
  """
  Obtiene todos los productos de la base de datos.
  """
  productos = Producto.objects.all()
  return productos

def get_producto_by_cod(cod_producto):
  """
  Obtiene un producto por su código de producto.
  """
  try:
    producto = Producto.objects.get(cod_producto=cod_producto)
  except Producto.DoesNotExist:
    return None
  return producto

def create_producto(producto_data):
  """
  Crea un nuevo producto en la base de datos.
  """
  serializer = ProductoSerializer(data=producto_data)
  if serializer.is_valid():
    serializer.save()
    return serializer.data
  return None
