from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.response import Response
from .services import get_all_productos, get_producto_by_cod, create_producto
from .serializers import ProductoSerializer

@api_view(['GET'])
def get_items(request):
  """
  Obtiene todos los productos.
  """
  productos = get_all_productos()
  serializer = ProductoSerializer(productos, many=True)
  return Response(serializer.data)

@api_view(['GET'])
def get_producto_detalle(request, cod_producto):
  """
  Obtiene un producto por su código.
  """
  producto = get_producto_by_cod(cod_producto)
  if producto is None:
    return Response(status=status.HTTP_404_NOT_FOUND)
  serializer = ProductoSerializer(producto)
  return Response(serializer.data)


@api_view(['POST'])
def registrar_producto(request):
  """
  Registra un nuevo producto.
  """
  serializer = ProductoSerializer(data=request.data)

  if serializer.is_valid():
    producto = create_producto(serializer.data)
    if producto:
      return Response(producto, status=status.HTTP_201_CREATED)
    else:
      return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
  return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
