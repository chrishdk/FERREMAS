from django.shortcuts import render
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from .models import Carrito, CarritoProducto, Producto
from .serializers import CarritoSerializer, CarritoProductoSerializer

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def agregar_producto_al_carrito(request):
    user = request.user
    producto_id = request.data.get('producto_id')
    cantidad = int(request.data.get('cantidad', 1))

    try:
        producto = Producto.objects.get(cod_producto=producto_id)
    except Producto.DoesNotExist:
        return Response({"error": "Producto no encontrado"}, status=status.HTTP_404_NOT_FOUND)

    carrito, created = Carrito.objects.get_or_create(user=user)

    carrito_producto, created = CarritoProducto.objects.get_or_create(carrito=carrito, producto=producto)
    if not created:
        carrito_producto.cantidad += cantidad
        carrito_producto.save()
    else:
        carrito_producto.cantidad = cantidad
        carrito_producto.save()

    return Response({"message": "Producto añadido al carrito"}, status=status.HTTP_201_CREATED)

class CarritoDetail(generics.RetrieveAPIView):
    queryset = Carrito.objects.all()
    serializer_class = CarritoSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return Carrito.objects.get(user=self.request.user)