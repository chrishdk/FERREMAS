from django.urls import path
from . import views

urlpatterns = [
    path('carrito/',views.CarritoDetail.as_view(), name='carrito-detalle'),
    path('carrito/agregar/', views.agregar_producto_al_carrito, name='agregar-producto-carrito'),
]