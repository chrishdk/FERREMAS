from django.db import models
from django.contrib.auth.models import User
from django.db import models

class Producto(models.Model):
    cod_producto = models.AutoField(primary_key=True)
    marca = models.CharField(max_length=50)
    cod = models.CharField(max_length=50)
    nombre = models.CharField(max_length=50)
    precio = models.IntegerField(default=0)

    def str(self):
        return self.nombre

class Carrito(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    creado_en = models.DateTimeField(auto_now_add=True)

class CarritoProducto(models.Model):
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE)
    producto = models.ForeignKey('carrito_compras.Producto', on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    agregado_en = models.DateTimeField(auto_now_add=True)