from django.apps import AppConfig


class CarritoComprasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'carrito_compras'
