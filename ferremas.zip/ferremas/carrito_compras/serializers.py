from .models import Carrito, CarritoProducto, Producto
from rest_framework import serializers

class ProductoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Producto
        fields = 'all'

class CarritoProductoSerializer(serializers.ModelSerializer):
    producto = ProductoSerializer(read_only=True)

    class Meta:
        model = CarritoProducto
        fields = '__all'

class CarritoSerializer(serializers.ModelSerializer):
    productos = CarritoProductoSerializer(source='carritoproducto_set', many=True, read_only=True)

    class Meta:
        model = Carrito
        fields = ['id', 'user', 'productos', 'creado_en']